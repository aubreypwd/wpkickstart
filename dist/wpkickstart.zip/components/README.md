[See Wiki](https://github.com/aubreypwd/wpkickstart/wiki/Components)
